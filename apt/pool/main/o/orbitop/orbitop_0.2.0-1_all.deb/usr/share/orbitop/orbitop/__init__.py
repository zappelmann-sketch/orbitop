# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright © 2026 zappelmann-sketch

__version__ = "0.2.0"
APP_ID = "io.github.zappelmann_sketch.orbitop"
